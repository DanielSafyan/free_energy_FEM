"""
    Add a third neutral species to the mode that does not interact with the other species through chemical potential nor electrical potential.

    -c1 is the cation (concentration field)
    -c2 is the anion (concentration field)
    -c3 is the neutral species (concentration field)
    -phi is the electrical potential field

    This version uses a semi-implicit operator splitting method to solve the NPP equations.
    The diffusion part is solved implicitly, and the drift part is solved explicitly.
    This gives direct control over the simulation speed via the dt parameter.
"""
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection

import numpy as np
import os
from scipy.sparse import lil_matrix, csc_matrix, hstack, vstack, eye
from scipy.sparse.linalg import spsolve
from tqdm import tqdm
from utils.fem_mesh import TriangularMesh

class NernstPlanckPoissonSimulation:
    def __init__(self, mesh, dt, D1, D2, D3, z1, z2, epsilon, R, T, 
                 L_c, c0, voltage=0.0, chemical_potential_terms=None, boundary_nodes=None):
        self.mesh = mesh
        self.F = 96485.33212  # Faraday's constant

        # Store characteristic scales
        self.L_c = L_c
        self.phi_c = R * T / self.F  # Thermal voltage
        self.D_c = max(D1, D2, D3) if max(D1, D2, D3) > 0 else 1.0
        self.c0 = c0
        self.tau_c = L_c**2 / self.D_c if self.D_c > 0 else 1.0

        # Dimensionless parameters
        self.dt_dim = dt / self.tau_c
        print("dt_dim: ", self.dt_dim)
        self.D1_dim = D1 / self.D_c if self.D_c > 0 else 0
        self.D2_dim = D2 / self.D_c if self.D_c > 0 else 0
        self.D3_dim = D3 / self.D_c if self.D_c > 0 else 0
        self.z1 = z1
        self.z2 = z2
        self.epsilon = epsilon
        self.R = R
        self.T = T
        
        self.voltage_dim = voltage / self.phi_c if self.phi_c > 0 else 0.0
        
        lambda_D_sq_dim = (epsilon * R * T) / (self.F**2 * c0)
        self.poisson_coeff = (L_c**2) / lambda_D_sq_dim
        
        self.chemical_potential_terms = chemical_potential_terms if chemical_potential_terms is not None else []

        self.num_nodes = mesh.num_nodes()
        self._assemble_constant_matrices()
        
        if boundary_nodes is not None:
            self.left_boundary_nodes = boundary_nodes[0]
            self.right_boundary_nodes = boundary_nodes[1]
        else: 
            self.left_boundary_nodes = np.where(self.mesh.nodes[:, 0] == 0)[0]
            self.right_boundary_nodes = np.where(np.isclose(self.mesh.nodes[:, 0], self.L_c, atol=self.L_c*0.0001))[0]
            if self.left_boundary_nodes.shape[0] != self.right_boundary_nodes.shape[0]:
                print("Warning: Number of boundary nodes on left and right are not equal.")
            print("Boundary nodes shape: ", self.left_boundary_nodes.shape, self.right_boundary_nodes.shape)

    def _assemble_constant_matrices(self):
        """Assembles the mass and stiffness matrices which are constant over time."""
        M = lil_matrix((self.num_nodes, self.num_nodes))
        K = lil_matrix((self.num_nodes, self.num_nodes))

        for cell_idx in range(self.mesh.num_cells()):
            nodes = self.mesh.get_nodes_for_cell(cell_idx)
            for i in range(len(nodes)):
                for j in range(len(nodes)):
                    mass_integral = self.mesh.integrate_phi_i_phi_j(cell_idx, i, j)
                    M[nodes[i], nodes[j]] += mass_integral
                    stiffness_integral = self.mesh.integrate_grad_phi_i_grad_phi_j(cell_idx, i, j)
                    K[nodes[i], nodes[j]] += stiffness_integral

        self.M_mat = csc_matrix(M)
        self.K_mat = csc_matrix(K)

    def _solve_diffusion_step(self, c1_prev, c2_prev, c3_prev):
        """Solves the implicit diffusion step for all species."""
        # System matrix for implicit diffusion: (M/dt + D*K)
        A1 = self.M_mat / self.dt_dim + self.D1_dim * self.K_mat
        A2 = self.M_mat / self.dt_dim + self.D2_dim * self.K_mat
        A3 = self.M_mat / self.dt_dim + self.D3_dim * self.K_mat

        # Right-hand side: M/dt * c_prev
        b1 = (self.M_mat / self.dt_dim) @ c1_prev
        b2 = (self.M_mat / self.dt_dim) @ c2_prev
        b3 = (self.M_mat / self.dt_dim) @ c3_prev

        # Solve for intermediate concentrations c*
        c1_star = spsolve(A1, b1)
        c2_star = spsolve(A2, b2)
        c3_star = spsolve(A3, b3) # Neutral species only diffuses

        return c1_star, c2_star, c3_star

    def _solve_poisson_step(self, c1, c2):
        """Solves the Poisson equation for the potential phi, applying boundary conditions."""
        A_poisson = self.K_mat.tolil()
        # Right-hand side is the scaled charge density
        rhs_poisson = -self.poisson_coeff * (self.z1 * self.M_mat @ c1 + self.z2 * self.M_mat @ c2)

        # Enforce Dirichlet BCs for voltage
        # Left boundary (phi = 0)
        for node_idx in self.left_boundary_nodes:
            rhs_poisson -= A_poisson[:, node_idx].toarray().flatten() * 0.0
            A_poisson[node_idx, :] = 0
            A_poisson[node_idx, node_idx] = 1
            rhs_poisson[node_idx] = 0.0
        
        # Right boundary (phi = V_applied)
        for node_idx in self.right_boundary_nodes:
            rhs_poisson -= A_poisson[:, node_idx].toarray().flatten() * self.voltage_dim
            A_poisson[node_idx, :] = 0
            A_poisson[node_idx, node_idx] = 1
            rhs_poisson[node_idx] = self.voltage_dim

        # Solve for potential
        phi = spsolve(A_poisson.tocsc(), rhs_poisson)
        return phi

    def _solve_drift_step(self, c1_star, c2_star, phi_star):
        """Solves the explicit drift step for charged species."""
        # Assemble the drift term matrix: K_drift = integral(c * grad(phi_j) . grad(phi))
        # This is equivalent to K_c_phi in the old monolithic solver
        K_c1_phi = self.mesh.assemble_coupling_matrix(self.D1_dim * self.z1 * c1_star)
        K_c2_phi = self.mesh.assemble_coupling_matrix(self.D2_dim * self.z2 * c2_star)

        # Calculate the change due to drift explicitly: delta_c = dt * (K_drift * phi)
        # Note: The mass matrix M is needed to correctly project the nodal forces
        # We solve M * delta_c = dt * (K_drift * phi)
        M_inv_K_c1_phi_phi = spsolve(self.M_mat, K_c1_phi @ phi_star)
        M_inv_K_c2_phi_phi = spsolve(self.M_mat, K_c2_phi @ phi_star)

        c1_new = c1_star - self.dt_dim * M_inv_K_c1_phi_phi
        c2_new = c2_star - self.dt_dim * M_inv_K_c2_phi_phi

        return c1_new, c2_new

    def run(self, c1_initial, c2_initial, c3_initial, phi_initial, num_steps):
        """
        Runs the simulation using operator splitting.
        """
        c1, c2, c3, phi = c1_initial.copy(), c2_initial.copy(), c3_initial.copy(), phi_initial.copy()
        history = [(c1.copy(), c2.copy(), c3.copy(), phi.copy())]

        for step in tqdm(range(num_steps), desc="Simulation Progress"):
            c1_prev, c2_prev, c3_prev = c1.copy(), c2.copy(), c3.copy()

            # --- Step 1: Solve Diffusion (Implicit) ---
            c1_star, c2_star, c3_star = self._solve_diffusion_step(c1_prev, c2_prev, c3_prev)
            print("change in c1_prev to c_star: ", np.linalg.norm(c1_star - c1_prev))

            # --- Step 2: Update Potential based on diffused concentrations ---
            phi_star = self._solve_poisson_step(c1_star, c2_star)
            print("change in phi_prev to phi_star: ", np.linalg.norm(phi_star - phi))

            # --- Step 3: Solve Drift (Explicit) ---
            c1_new, c2_new = self._solve_drift_step(c1_star, c2_star, phi_star)
            print("change in c1_star to c1_new: ", np.linalg.norm(c1_new - c1_star))
            
            
            # The neutral species is not affected by drift
            c3_new = c3_star
            
            # Update the state for the next iteration
            c1, c2, c3, phi = c1_new, c2_new, c3_new, phi_star

            history.append((c1.copy(), c2.copy(), c3.copy(), phi.copy()))

        return history

if __name__ == '__main__':
    from utils.fem_mesh import create_structured_mesh 

    # 1. Simulation Setup
    nx, ny = 30, 30
    Lx, Ly = 1.0e-7, 1.0e-7
    # Note: The create_structured_mesh function must be adapted to return boundary_nodes if used
    nodes, elements, boundary_nodes = create_structured_mesh(Lx=Lx, Ly=Ly, nx=nx, ny=ny)
    mesh = TriangularMesh(nodes, elements)

    # 2. Physical Parameters & Characteristic Scales
    R = 8.314
    T = 298.0
    F = 96485.33
    epsilon = 80 * 8.854e-12
    D1 = 1e-9
    D2 = 1e-9
    D3 = 1e-9 
    z1 = 1
    z2 = -1
    
    applied_voltage = 1e-12  # Volts

    # Characteristic scales
    c0 = 1.0  # mol/m^3
    L_c = Lx  

    # A smaller dt will result in smaller changes per frame.
    dt = 1e-10
    num_steps = 1

    # Stability condition for the explicit drift step is roughly dt < dx^2 / (D*z*V)
    # This is a loose guide; you may need to adjust dt based on simulation behavior.
    dx = Lx / nx
    dt_drift_limit = (dx**2) / (D1 * abs(z1) * applied_voltage / (R*T/F)) if applied_voltage > 0 else float('inf')
    print(f"Estimated stability limit for dt from drift: {dt_drift_limit:.2e} s")
    if dt > dt_drift_limit:
        print(f"Warning: dt ({dt:.2e}) may be too large for stability. Consider reducing it below {dt_drift_limit:.2e} s.")


    print(f"Thermal voltage = {R*T/F}")

    # 3. Define non-ideal chemical potential terms (optional, not used in this scheme)
    chemical_potential_terms = []

    # 4. Create simulation instance
    sim = NernstPlanckPoissonSimulation(
        mesh, dt, D1, D2, D3, z1, z2, epsilon, R, T, L_c, c0,
        voltage=applied_voltage, 
        chemical_potential_terms=chemical_potential_terms,
        boundary_nodes=None
    )

    # 5. Set Initial Conditions (Dimensionless)
    experiment = "gaussian"  # Options: "random", "gaussian", "two_blocks"

    c3_initial_dim = np.full(mesh.num_nodes(), 0.9)
    if experiment == "gaussian":
        center_x, center_y = Lx / 2, Ly / 2
        sigma = Lx / 10
        c1_initial_dim = 0.05 + 0.04 * np.exp(-((nodes[:, 0] - center_x)**2 + (nodes[:, 1] - center_y)**2) / (2 * sigma**2))
        c2_initial_dim = 1.0 - c3_initial_dim - c1_initial_dim
    else: # Default to random
        c1_initial_dim = 0.05 + np.random.uniform(-0.01, 0.01, mesh.num_nodes())
        c2_initial_dim = 1.0 - c3_initial_dim - c1_initial_dim
    
    # Calculate the initial potential based on the initial concentrations
    phi_initial_dim = sim._solve_poisson_step(c1_initial_dim, c2_initial_dim)
    
    # 6. Run simulation
    history = sim.run(c1_initial_dim, c2_initial_dim, c3_initial_dim, phi_initial_dim, num_steps)

    print(f"Simulation finished. History contains {len(history)} snapshots.")

    # 7. Save and Plot results (unchanged)
    output_dir = "output"
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    c1_history = np.array([c1 for c1, c2, c3, phi in history])
    c2_history = np.array([c2 for c1, c2, c3, phi in history])
    c3_history = np.array([c3 for c1, c2, c3, phi in history])
    phi_history = sim.phi_c * np.array([phi for c1, c2, c3, phi in history])

    file_path = os.path.join(output_dir, "water_simulation_results_split.npz")
    np.savez(file_path,
             nodes=mesh.nodes,
             elements=mesh.elements,
             c1_history=c1_history,
             c2_history=c2_history,
             c3_history=c3_history,
             phi_history=phi_history,
             dt=dt)

    print(f"Simulation data saved to '{file_path}'")

    plot_option = "history"
    if num_steps < 100:
        data = np.load(file_path)
        nodes = data['nodes']
        elements = data['elements']
        c1_history = data['c1_history']
        phi_history = data['phi_history']
        dt = data['dt'].item()

        for i in range(len(phi_history)):
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13, 5))

            # Plot c1
            c1_triangle_values = c1_history[i][elements].mean(axis=1)
            collection1 = ax1.tripcolor(nodes[:, 0], nodes[:, 1], elements, facecolors=c1_triangle_values, cmap='viridis', vmin=0.04, vmax=0.1)
            ax1.triplot(nodes[:, 0], nodes[:, 1], elements, 'k-', lw=0.2)
            ax1.set_title(f"c1 at t = {i*dt*1e12:.2f} ps")
            fig.colorbar(collection1, ax=ax1, label="Concentration Fraction")
            ax1.set_aspect('equal')
            ax1.set_xlabel("x (m)")
            ax1.set_ylabel("y (m)")

            # Plot phi
            phi_triangle_values = phi_history[i][elements].mean(axis=1)
            collection2 = ax2.tripcolor(nodes[:, 0], nodes[:, 1], elements, facecolors=phi_triangle_values, cmap='plasma', vmin=0, vmax=applied_voltage)
            ax2.triplot(nodes[:, 0], nodes[:, 1], elements, 'k-', lw=0.2)
            ax2.set_title(f"phi at t = {i*dt*1e12:.2f} ps")
            fig.colorbar(collection2, ax=ax2, label="Potential (V)")
            ax2.set_aspect('equal')
            ax2.set_xlabel("x (m)")

            plt.tight_layout()
            plt.show()
