"""
Backend selection utility for NumPy/CuPy compatibility.

This module provides a consistent interface for array operations,
automatically selecting CuPy if a GPU is available and falling back to NumPy otherwise.
It also handles the selection of compatible sparse matrix libraries.
"""

# Try to import CuPy
try:
    import cupy as cp
    import cupyx.scipy.sparse as cupy_sparse
    import cupyx.scipy.sparse.linalg as cupy_sparse_linalg
    
    # Check if CUDA is actually available
    if cp.cuda.is_available():
        xp = cp  # Use CuPy as the array library
        sparse_lib = cupy_sparse
        sparse_linalg_lib = cupy_sparse_linalg
        backend_name = "CuPy"
        print(f"Using {backend_name} backend with GPU acceleration.")
    else:
        raise ImportError("CuPy is installed but CUDA is not available.")
except (ImportError, ModuleNotFoundError):
    # Fallback to NumPy if CuPy is not available or CUDA is not available
    import numpy as np
    import scipy.sparse as scipy_sparse
    import scipy.sparse.linalg as scipy_sparse_linalg
    
    xp = np  # Use NumPy as the array library
    sparse_lib = scipy_sparse
    sparse_linalg_lib = scipy_sparse_linalg
    backend_name = "NumPy"
    print(f"Using {backend_name} backend (no GPU acceleration).")

# Export the selected libraries and functions
# Array creation and manipulation functions
array = xp.array
zeros = xp.zeros
ones = xp.ones
linspace = xp.linspace
vstack = xp.vstack
hstack = xp.hstack if hasattr(xp, 'hstack') else None  # CuPy might not have hstack at module level
meshgrid = xp.meshgrid
where = xp.where
isclose = xp.isclose
abs = xp.abs
mean = xp.mean
sum = xp.sum
dot = xp.dot
linalg_norm = xp.linalg.norm
linalg_det = xp.linalg.det
linalg_inv = xp.linalg.inv

# Sparse matrix classes and functions
lil_matrix = sparse_lib.lil_matrix
csc_matrix = sparse_lib.csc_matrix
hstack_sparse = sparse_lib.hstack
vstack_sparse = sparse_lib.vstack

# Sparse linear algebra solver
spsolve = sparse_linalg_lib.spsolve
norm = sparse_linalg_lib.norm  # For matrix norms

__all__ = [
    'xp', 'backend_name',
    'array', 'zeros', 'ones', 'linspace', 'vstack', 'meshgrid', 'where', 'isclose', 'abs', 
    'mean', 'sum', 'dot', 'linalg_norm', 'linalg_det', 'linalg_inv',
    'lil_matrix', 'csc_matrix', 'hstack_sparse', 'vstack_sparse',
    'spsolve', 'norm'
]
